<?php

return [
	'table_prefix'			=> 'indonesia_',
];
