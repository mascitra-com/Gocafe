<?php $__env->startSection('page_title', 'Cafe Branches'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul style="margin: 0 1em">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="content-title">Branches Management</div>
    <div class="row break-20">
        <div class="col-xs-12 nopadding">
            <div class="panel panel-theme">
                <div class="panel-heading">
                    <h3 class="panel-title pull-left">Branches</h3>
                    <div class="btn-group btn-group-sm pull-right" role="group">
                        <a class="btn btn-default" href="#"><i class="fa fa-fw fa-refresh"></i> <span class="hidden-sm">Refresh</span></a>
                        <button class="btn btn-default" data-toggle="modal" data-target="#add-branches"><i
                                    class="fa fa-fw fa-plus"></i> <span class="hidden-sm">New</span></button>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-body table-responsive table-full">
                    <table class="table table-stripped">
                        <tbody>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td>Cabang <?php echo e($branch->location->name); ?></td>
                                <td>
                                    <?php echo e(isset($branch->location->city) ? $branch->location->city->name. ',' : ''); ?>

                                    <?php echo e(isset($branch->location->province) ? $branch->location->province->name: ''); ?>

                                </td>
                                <td><?php echo e($branch->address); ?></td>
                                <td><?php echo e($branch->open_hours); ?></td>
                                <td><?php echo e($branch->close_hours); ?></td>
                                <td class="text-right"><a href="<?php echo e(url('branch/'.$branch->id.'/edit')); ?>" class="btn btn-xs btn-default"><i class="fa fa-info-circle fa-fw"></i> detail</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <style>
        .nopadding {
            padding: 0;
        }

        .table > tbody tr td {
            padding-top: 20px;
            padding-bottom: 15px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <div class="modal fade" tabindex="-1" role="dialog" id="add-branches">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">New Branches</h4>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(url("branch")); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="">Location</label>
                            <div class="row">
                                <div class="col-xs-12 col-md-4">
                                    <select name="province_id" class="form-control" id="provinces">
                                        <option value="">Pilih Provinsi</option>
                                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo e($province->id); ?>"><?php echo e($province->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-xs-12 col-md-4">
                                    <select name="city_id" class="form-control" id="cities">
                                        <option value="">Pilih Kabupaten / Kota</option>
                                    </select>
                                </div>
                                <div class="col-xs-12 col-md-4">
                                    <select name="district_id" class="form-control" id="districts">
                                        <option value="">Pilih Kecamatan</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Address</label>
                            <textarea name="address" class="form-control" placeholder="Branch address"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="">Phone Number</label>
                            <input type="text" class="form-control" name="phone" placeholder="phone number">
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-md-6">
                                <div class="form-group">
                                    <label for="">Open Hours</label>
                                    <input type="text" class="form-control" name="open_hours" placeholder="open hours">
                                </div>
                            </div>
                            <div class="col-xs-12 col-md-6">
                                <div class="form-group">
                                    <label for="">Close Hours</label>
                                    <input type="text" class="form-control" name="close_hours"
                                           placeholder="close hours">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary"><i class="fa fa-save fa-fw"></i> save</button>
                            <button class="btn btn-default"><i class="fa fa-refresh fa-fw"></i> reset</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascripts'); ?>
    <script>
        var token = $('meta[name="csrf-token"]').attr('content');
        $("#provinces").on('change', function () {
            $("#cities").html("<option>Pilih Kabupaten / Kota</option>");
            $("#cities").prop('disabled', true);
            var id;
            var x = document.getElementById("provinces");
            for (var i = 0; i < x.options.length; i++) {
                if (x.options[i].selected) {
                    id = x.options[i].value;
                }
            }
            $.ajaxSetup({
                headers: { 'X-CSRF-TOKEN': token }
            });
            $.ajax({
                type: 'POST',
                data: { 'idProvince' : id },
                dataType: "json",
                url: "branch/getCitiesByProvince",
                success: function (data) {
                    $("#cities").html(data);
                    $("#cities").prop('disabled', false);
                }
            });
        });
    </script>
    <script>
        var token = $('meta[name="csrf-token"]').attr('content');
        $("#cities").on('change', function () {
            $("#districts").html("<option>Pilih Kabupaten / Kota</option>");
            $("#districts").prop('disabled', true);
            var id;
            var x = document.getElementById("cities");
            for (var i = 0; i < x.options.length; i++) {
                if (x.options[i].selected) {
                    id = x.options[i].value;
                }
            }
            $.ajaxSetup({
                headers: { 'X-CSRF-TOKEN': token }
            });
            $.ajax({
                type: 'POST',
                data: { 'idCity' : id },
                dataType: "json",
                url: "branch/getDistrictByCity",
                success: function (data) {
                    $("#districts").html(data);
                    $("#districts").prop('disabled', false);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layout/dashboard/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>