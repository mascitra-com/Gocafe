<?php $__env->startSection('page_title', 'Diskon'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xs-12">
        <div class="panel panel-theme">
            <div class="panel-heading">
                <h4 class="panel-title">Add Discount</h4>
            </div>
            <form action="<?php echo e(url('discount')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="panel-body">
                    <div class="row">
                        <div class="col-xs-12 col-md-6">
                            <div class="form-group">
                                <label for="name">Discount Name</label>
                                <input type="text" class="form-control" name="name" placeholder="Discount Name"
                                required/>
                            </div>
                        </div>
                        <div class="col-xs-12 col-md-6">
                            <div class="form-group">
                                <label for="value">Amount</label>
                                <div class="input-group">
                                    <input type="number" name="value" min="1" max="100" class="form-control" required/>
                                    <span class="input-group-addon">%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 col-md-6">
                            <div class="form-group">
                                <label for="start_date">Start Date</label>
                                <input type="date" name="start_date" class="form-control"
                                placeholder="Start Date"/>
                                <p class="help-block">* Leave it blank if start from today</p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-md-6">
                            <div class="form-group">
                                <label for="expired_date">Expiration Date</label>
                                <input type="date" name="expired_date" class="form-control"
                                placeholder="Expiration Date"/>
                                <p class="help-block">* Leave it blank if no expiration date</p>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea class="form-control" name="description"
                        placeholder="Discount Description"></textarea>
                    </div>
                    <div class="panel-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                        <button type="reset" class="btn btn-warning">Clear</button>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
        
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('javascripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layout/dashboard/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>