<?php $__env->startSection('page_title', 'Detail new staff'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-xs-12 col-md-9">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title"><i class="fa fa-plus"></i> Detail Staff</h3>
			</div>
			<div class="panel-body">
				<form method="POST" action="<?php echo e(url('staff/'.$staff->id)); ?>">
				<?php echo e(method_field('PATCH')); ?>

				<?php echo e(csrf_field()); ?>

				<div class="form-group">
						<label for="email">Email</label>
						<input type="email" class="form-control" name="email" placeholder="email staff" value="<?php echo e($staff->user->email); ?>">
					</div>
					<div class="row">
						<div class="col-xs-6">
							<div class="form-group">
								<label for="first_name">First Name</label>
								<input type="text" class="form-control" name="first_name" placeholder="first name" value="<?php echo e($staff->first_name); ?>">
							</div>
						</div>
						<div class="col-xs-6">
							<div class="form-group">
								<label for="last_name">Last Name</label>
								<input type="text" class="form-control" name="last_name" placeholder="last name" value="<?php echo e($staff->last_name); ?>">
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="address">Address</label>
						<textarea name="address" class="form-control" placeholder="address"><?php echo e($staff->address); ?></textarea>
					</div>
					<div class="form-group">
						<label for="">Birth Date</label>
						<div class="row">
							<div class="col-xs-3">
								<select name="birthdate_day" class="form-control">
									<?php for($i=1;$i<=31;$i++): ?>
									<option value="<?php echo e($i); ?>" <?php if($i == date('d' , strtotime($staff->birthdate))): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo str_pad($i,2,'0',STR_PAD_LEFT)?></option>
									<?php endfor; ?>
								</select>
							</div>
							<div class="col-xs-5">
								<select name="birthdate_month" class="form-control">
									<?php for($i=1;$i<=12;$i++): ?>
									<option value="<?php echo e($i); ?>" <?php if($i == date('m' , strtotime($staff->birthdate))): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo date('F', strtotime('1-'.$i.'-2000')) ?></option>
									<?php endfor; ?>
								</select>
							</div>
							<div class="col-xs-4">
								<select name="birthdate_year" class="form-control">
									<?php for($i=date('Y');$i>=1945;$i--): ?>
									<option value="<?php echo e($i); ?>" <?php if($i == date('Y' , strtotime($staff->birthdate))): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($i); ?></option>
									<?php endfor; ?>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="">Gender</label><br>
						<label class="radio-inline">
							<input type="radio" name="gender" value="0" <?php if($staff->gender === '0'): ?> <?php echo e('checked'); ?><?php endif; ?>> Male
						</label>
						<label class="radio-inline">
							<input type="radio" name="gender" value="1" <?php if($staff->gender === '1'): ?> <?php echo e('checked'); ?><?php endif; ?>> Female
						</label>
					</div>
					<div class="form-group">
						<label for="">Phone Number</label>
						<div class="input-group">
							<span class="input-group-addon">+62</span>
							<input type="text" class="form-control" name="phone_input" placeholder="phone number" value="<?php echo e(substr($staff->phone, 3)); ?>">
						</div>
					</div>
					<div class="row">
						<div class="col-xs-12 col-sm-6">
							<div class="form-group">
								<label for="branch_id">Cabang</label>
								<select name="branch_id" class="form-control">
									<?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
									<option value="<?php echo e($branch->id); ?>" <?php if($branch->id === $staff->branch_id ): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($branch->id); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
								</select>
							</div>
						</div>
						<div class="col-xs-12 col-sm-6">
							<div class="form-group">
								<label for="position_id">Posisi</label>
								<div class="input-group">
									<select class="form-control" name="position_id">
										<?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
										<option value="<?php echo e($position->id); ?>" <?php if($position->id === $staff->position_id ): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($position->title); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
									</select>
									<span class="input-group-btn">
										<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#position">baru</button>
									</span>
								</div>
							</div>
						</div>
					</div>
					<div class="break-30"></div>
					<div class="form-group">
						<button class="btn btn-primary" type="submit"><i class="fa fa-save"></i> save changes</button>
						<button class="btn btn-default"><i class="fa fa-refresh"></i> reset</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="col-xs-12 col-md-3">
		<div class="panel panel-default">
			<div class="panel-body">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate aut vitae, excepturi, ad molestias quisquam numquam inventore totam hic officia voluptate, veritatis esse facilis. Eius hic, nam. Libero, explicabo, nemo.</p>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layout/dashboard/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>