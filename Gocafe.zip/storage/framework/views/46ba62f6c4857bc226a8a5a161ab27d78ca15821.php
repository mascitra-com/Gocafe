<?php $__env->startSection('page_title', 'Staff Management'); ?>

<?php $__env->startSection('styles'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script type="text/javascript">var base_url = '<?php echo e(url()->full()); ?>'</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-xs-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title pull-left"><i class="fa fa-fw fa-users"></i> Staff Management</h3>
				<div class="btn-group btn-group-sm pull-right" role="group">
					<a class="btn btn-default" href="#"><i class="fa fa-fw fa-refresh"></i> <span class="hidden-sm">refresh</span></a>
					<a class="btn btn-default" href="<?php echo e(url('staff/create')); ?>"><i class="fa fa-fw fa-plus"></i> <span class="hidden-sm">new</span></a>
					<button class="btn btn-default" data-toggle="modal" data-target="#import-dialog"><i class="fa fa-fw fa-upload"></i> <span class="hidden-sm">import</span></button>
				</div>
				<!-- QUICK SEARCH -->
				<form action="#" class="pull-right hidden-xs">
					<div class="form-group">
						<div class="input-group input-group-sm">
							<input type="text" class="form-control" placeholder="search">
							<span class="input-group-btn">
								<button class="btn btn-default"><i class="fa fa-search"></i></button>
							</span>
						</div>
					</div>
				</form>
				<div class="clearfix"></div>
			</div>
			<div class="panel-body table-responsive table-full">
				<table class="table table-stripped table-hover table-bordered">
					<thead>
						<tr>
							<th class="text-center">Staff ID</th>
							<th>First Name</th>
							<th>Last Name</th>
							<th class="text-center text-nowrap">Cafe Branch</th>
							<th class="text-center text-nowrap">Position</th>
							<th class="text-center text-nowrap">Gender</th>
							<th class="text-center text-nowrap">Action</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<!-- FORM FILTER -->
							<form action="#">
								<td><input type="text" class="form-control input-sm" name="id" placeholder="staff id"></td>
								<td><input type="text" class="form-control input-sm" name="first_name" placeholder="first name"></td>
								<td><input type="text" class="form-control input-sm" name="last_name" placeholder="last name"></td>
								<td>
									<select name="branch_id" class="form-control input-sm">
										<option value="">All</option>
										<option value="1">Branch #1</option>
									</select>
								</td>
								<td>
									<select name="position_id" class="form-control input-sm">
										<option value="">All</option>
										<option value="1">Position #1</option>
									</select>
								</td>
								<td>
									<select name="gender" class="form-control input-sm">
										<option value="">All</option>
										<option value="0">Male</option>
										<option value="1">Female</option>
									</select>
								</td>
								<td><button class="btn btn-sm btn-default btn-block"><i class="fa fa-search"></i></button></td>
							</form>
						</tr>
						<!-- DATA START HERE -->
						<?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<tr>
							<td class="text-center text-nowrap"><?php echo e($staff->id); ?></td>
							<td><?php echo e($staff->first_name); ?></td>
							<td><?php echo e($staff->last_name); ?></td>
							<td class="text-center text-nowrap"><?php echo e($staff->branches->id); ?></td>
							<td class="text-center text-nowrap"><?php echo e($staff->position->title); ?></td>
							<td class="text-center text-nowrap"><?php if($staff->gender === '0'): ?> Laki-Laki <?php else: ?> Perempuan <?php endif; ?></td>
							<td class="text-center text-nowrap">
								<a href="<?php echo e(url('staff/'.$staff->id.'/edit')); ?>" class="btn btn-default btn-xs"><i class="fa fa-info-circle"></i></a>
								<button class="btn btn-default btn-xs" onclick="delete_staff('<?php echo e($staff->id); ?>')" id="delete-staff"><i class="fa fa-trash"></i></button>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</tbody>
				</table>
			</div>
			<div class="panel-footer">
				<span class="panel-footer-text text-grey text-size-12 pull-left"><i class="fa fa-info-circle"></i> last edited at 02/01/2016 18:00</span>
				<nav aria-label="Page navigation" class="pull-right">
					<ul class="pagination pagination-sm">
						<li>
							<span aria-hidden="true">Show</span>
						</li>
						<li><a href="#">10</a></li>
						<li><a href="#">50</a></li>
						<li><a href="#">100</a></li>
						<li>
							<a href="#" aria-label="Previous">
								<span aria-hidden="true">&laquo;</span>
							</a>
						</li>
						<li><a href="#">1</a></li>
						<li><a href="#">2</a></li>
						<li><a href="#">3</a></li>
						<li><a href="#">4</a></li>
						<li><a href="#">5</a></li>
						<li>
							<a href="#" aria-label="Next">
								<span aria-hidden="true">&raquo;</span>
							</a>
						</li>
					</ul>
				</nav>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div class="modal fade" tabindex="-1" role="dialog" id="import-dialog">
	<div class="modal-dialog modal-sm" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Import data</h4>
			</div>
			<div class="modal-body">
				<p>Import data staff dalam bentuk file excel. Gunakan format file yang telah disediakan dibawah</p>
				<div class="break-50"></div>
				<form action="<?php echo e(url('staff/import')); ?>" method="POST" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

					<div class="form-group">
						<label for="import_excel"> Pilih file</label>
						<input type="file" name="import_excel">
					</div>
					<button class="btn btn-primary" type="submit">Upload</button>
					<a href="<?php echo e(url('staff/download')); ?>" class="btn btn-default"><i class="fa fa-download"></i> download format file</a>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
	.pagination{
		margin: 0;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascripts'); ?>
<script type="text/javascript" src="<?php echo e(URL::asset('js/Staff/staff.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layout/dashboard/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>