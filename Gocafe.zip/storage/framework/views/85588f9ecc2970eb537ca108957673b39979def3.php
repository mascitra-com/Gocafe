<?php $__env->startSection('page_title', 'Cafe Profile'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul style="margin: 0 1em">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
		<div class="col-xs-12 col-md-8">
			<div class="panel panel-default">
				<div class="panel-body">
					<h3 class="panel-title">Basic Info</h3>
					<form action="<?php echo e(URL('profile/cafe/'.(($cafe != NULL) ? $cafe->id : ''))); ?>" method="POST">
                        <?php echo e(($cafe != NULL) ? method_field('PATCH') : ''); ?>

                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
							<label for="">Cafe Name</label>
							<input type="text" class="form-control" name="name" placeholder="Cafe Name" value="<?php echo e(($cafe == NULL) ? old('name') : $cafe->name); ?>">
						</div>
						<div class="form-group">
							<label for="">Description</label>
							<textarea name="description" class="form-control" placeholder="Cafe Description"><?php echo e(($cafe == NULL) ? old('description') : $cafe->description); ?></textarea>
						</div>
						<div class="form-group">
							<button class="btn btn-primary" type="submit"><i class="fa fa-save"></i> Save Basic Info</button>
							<button class="btn btn-default" type="reset"><i class="fa fa-refresh"></i> Reset</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-md-4">
			<div class="panel panel-default">
				<div class="panel-body">
					<h3 class="panel-title">Contact Info</h3>
                    <form action="<?php echo e(URL('profile/cafe/updateContact/'.($cafe == NULL ? '' : $cafe->id))); ?>" method="POST">
                        <?php echo e(method_field('PATCH')); ?>

                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
							<label for=""><i class="fa fa-phone"></i> Phone Number</label>
							<input type="text" class="form-control" name="phone" placeholder="Phone Number" value="<?php echo e(($cafe == NULL) ? old('phone') : $cafe->phone); ?>">
						</div>
						<div class="form-group">
							<label for=""><i class="fa fa-facebook"></i> Facebook</label>
							<input type="text" class="form-control" name="facebook" placeholder="Facebook" value="<?php echo e(($cafe == NULL) ? old('facebook') : $cafe->facebook); ?>">
						</div>
						<div class="form-group">
							<label for=""><i class="fa fa-twitter"></i> Twitter</label>
							<input type="text" class="form-control" name="twitter" placeholder="Twitter" value="<?php echo e(($cafe == NULL) ? old('twitter') : $cafe->twitter); ?>">
						</div>
						<div class="form-group">
							<label for=""><i class="fa fa-instagram"></i> Instagram</label>
							<input type="text" class="form-control" name="instagram" placeholder="Instagram" value="<?php echo e(($cafe == NULL) ? old('instagram') : $cafe->instagram); ?>">
						</div>
						<div class="form-group">
							<button class="btn btn-primary" type="submit"><i class="fa fa-save"></i> Save Contact Info</button>
							<button class="btn btn-default" type="reset"><i class="fa fa-refresh"></i> Reset</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
	<style>
		.container-fluid > .row > [class*=col-]{
			padding-left: 5px;
			padding-right: 5px;
		}

		.panel{
			padding-left: 10px;
			padding-right: 10px;
		}

		.panel-title{
			color:#AAA;
			margin-bottom: 20px;
		}

		.btn-xs{
			padding: 3px 10px;
		}

		.radio-inline{
			border: 1px #AAA solid;
			border-radius: 10px;
			padding: 3px 10px 3px 25px;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layout/dashboard/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>